package com.cybage.exception;

public class UserException extends Exception{
	public UserException(String msg) {
		super(msg);
	}
}
