# G-1-MiniProject
Mini Project
